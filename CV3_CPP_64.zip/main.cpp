// main.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include<iostream>
#include<opencv2/opencv.hpp>


using namespace cv;
using namespace std;


int main(int argc, char** argv)
{

	Mat image;
	String imageName("lena.jpg");
	if (argc >= 2) {
		imageName = argv[1];
	}
	image = imread(imageName, IMREAD_COLOR);
	if (image.empty())                      // Check for invalid input
	{
		std::cout << std::endl << "Could not open or find the image" << std::endl;
		std::cout << "Image Name: " << imageName << std::endl;
		std::cout << "Number of arguments :" << argc << std::endl;
		return -1;
	}

	imshow(imageName, image);

	waitKey(0);


}